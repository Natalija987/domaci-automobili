public class WhilePetlja {
    public static void main(String[] args) {
        int brojac = 10;
        while (brojac > 0) {
            System.out.println(brojac);
            //brojac = brojac - 1;
            brojac--;
        }

        System.out.println("POLECEMO!");
    }
}