import java.util.Arrays;
import java.util.Scanner;
public class Nizovi3 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Unesite duzinu niza: ");
        int l = scanner.nextInt();
        int[] arr = new int[l];
        for (int i = 0; i < l; i++) {
            System.out.print("Unesite " + (i + 1) + " element niza: ");
            arr[i] = scanner.nextInt();
        }System.out.print("Niz unazad je ");
        for(int i=l-1; i>=0; i--){
            System.out.print(arr[i]);
                    }

        for (int k=0; k<l; k++){
            if (arr[k]%2!=0){

                System.out.println("Neparni brojevi su " + arr[k] );
            }
        }
    }
}
