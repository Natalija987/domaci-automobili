import java.util.Scanner;

public class Vezba2 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Unesite dan u nedelji: ");
        String danUNedelji = scanner.nextLine();
        if (danUNedelji.equals("ponedeljak") || danUNedelji.equals("utorak") || danUNedelji.equals("cetvrtak") || danUNedelji.equals("petak")) {
            System.out.println("Imamo cas u ITBootcampu");
        } else if (danUNedelji.equals("sreda") || danUNedelji.equals("subota") || danUNedelji.equals("nedelja")) {
            System.out.println("Nemamo cas u ITBootcampu");
        } else {
            System.out.println("Pogresan unos");

        }
        System.out.println("***Kraj programa***");
    }
}
