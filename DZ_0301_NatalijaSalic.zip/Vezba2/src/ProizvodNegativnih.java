import java.util.Scanner;

public class ProizvodNegativnih {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Unesite prvi broj: ");
        int prviBroj = scanner.nextInt();
        int x = Math.abs(prviBroj);
        Scanner scanner2 = new Scanner(System.in);
        System.out.print("Unesite drugi broj: ");
        int drugiBroj = scanner2.nextInt();
        int y = Math.abs(drugiBroj);
        int proizvod = 0;
        int i = x;
        while (i > 0) {
            proizvod = proizvod + y;
            i--;

        }
        if ((prviBroj>0 && drugiBroj>0) || (prviBroj<0 && drugiBroj<0)){
            System.out.println("Proizvod je: " + proizvod );

        } else if ((prviBroj<0 && drugiBroj>0) || (prviBroj>0 && drugiBroj<0)){
            System.out.println("Proizvod je: " + -proizvod );
        }
        else if (prviBroj==0 || drugiBroj==0) {
            System.out.println("Proizvod je 0");        }
    }
}



