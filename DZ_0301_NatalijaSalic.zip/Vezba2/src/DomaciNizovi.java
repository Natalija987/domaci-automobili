public class DomaciNizovi {
    public static void main(String[] args) {
        String[] mojNiz = {"Marko", "Natalija", "Ivana", "Milos"};
        System.out.println("Imena koja pocinju sa slovom M su:");
        for (int i = 0; i < mojNiz.length; i++) {
            if (mojNiz[i].startsWith("M")) {
                System.out.println(mojNiz[i]);
            }
        }
    }
}