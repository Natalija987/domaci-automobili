import java.util.Scanner;

public class Mesec {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        //Napisati program koji uzima input sa skenera (mesec) i racuna koliko dana ima zadati mesec
        //*ali, uracunati i za prestupnu godinu
        System.out.println("Unesite odredjeni mesec");
        switch (scanner.nextLine()) {
            case "februar":
                System.out.println("Mesec ima 29 dana");
                break;
            case "januar":
            case "mart":
            case "maj":
            case "jul":
            case "avgust":
            case "oktobar":
            case "decembar":
                System.out.println("Mesec ima 31 dan");
                break;
            case "april":
            case "jun":
            case "septembar":
            case "novembar":
                System.out.println("30 dana");
                break;
            default:
                System.out.println("pogresan unos");
        }
    }
}
