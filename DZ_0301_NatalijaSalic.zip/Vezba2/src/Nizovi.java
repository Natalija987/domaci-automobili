import java.util.Locale;
import java.util.Scanner;
import java.util.Arrays;
public class Nizovi{
    public static void main(String []args){

        System.out.println("Upisite broj imena u nizu:\n");
        Scanner scanner = new Scanner(System.in);
        int velicinaNiza = scanner.nextInt();
        String[] mojNiz = new String [velicinaNiza +1];
        int brojacUnetihImena = 0;

        System.out.println("Dodajte " + velicinaNiza + " imena u niz:");

        while(brojacUnetihImena<=velicinaNiza)
        {
            String ime = scanner.nextLine();
            mojNiz[brojacUnetihImena] = ime;
            brojacUnetihImena ++;
        }

        System.out.println("Imena koja pocinju sa slovom M su:");

        for (int i = 0; i < mojNiz.length; i++) {
            String ime = mojNiz[i].toLowerCase();
            if (ime.startsWith("m")) {
                System.out.println(ime);
            }

        }

    }
}