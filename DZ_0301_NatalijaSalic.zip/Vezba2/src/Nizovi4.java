/*import java.util.Arrays;

class Nizovi4 {
    public static void main(String[] args) {
        int[] prviNiz={10,20,30,40,50,60};
        System.out.println("Originalni niz: " + Arrays.toString(prviNiz));
        System.out.println("Elementi koji se brisu: " +  prviNiz[2] + " i " + prviNiz[3]);
        System.out.println("Niz posle brisanja: ");
       /* int[] noviNiz = int[prviNiz.length-1];
        for(int i=0);
    }

}*/