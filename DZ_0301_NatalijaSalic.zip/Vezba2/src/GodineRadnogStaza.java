import java.util.Scanner;

public class GodineRadnogStaza {   public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        System.out.println("unesite godinu zaposlenja");
        int godinaPocetka=scanner.nextInt();
        int trennutnaGodina=2022;
        int radniStaz=trennutnaGodina-godinaPocetka;
        if (trennutnaGodina-godinaPocetka<4){
            System.out.println("junior");
        } else if(trennutnaGodina-godinaPocetka<8){
            System.out.println("senior");}
            else if (trennutnaGodina-godinaPocetka>8){
                System.out.println("direktor");
            }
        }
    }

