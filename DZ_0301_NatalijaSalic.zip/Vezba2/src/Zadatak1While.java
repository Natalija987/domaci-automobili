import java.util.Scanner;
public class Zadatak1While {
    public static void main(String[] args) {
         //pomocu while petlji ispisi brojeve od 1 do 10
        //ispisi samo one brojeve koji su parni
    int brojac=0;
    int suma=0;
    Scanner scanner=new Scanner(System.in);
    System.out.println("Unesite granicnu vrednost");
    int granicnaVrednost= scanner.nextInt();
while(brojac<=granicnaVrednost){
    System.out.println("brojac je sada: " + brojac);
    suma+= brojac;
    System.out.println("suma je sada: " + suma);
brojac=brojac+2;

}System.out.println("nastavak programa , suma je: " + suma);

    }
}
