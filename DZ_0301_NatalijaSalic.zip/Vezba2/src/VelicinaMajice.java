import java.util.Scanner;

public class VelicinaMajice {
    public static void main(String[] args) {
        //Napisati program gde cete uneti velicinu majice: 24( Ispise: S velicina), 30cm(Ispise: M Velicina), 36cm (ispise: L velicina), 42cm(ispise: XL velicina)
        //u suprotnom izbaciti gresku u nepostojecoj velicini. Ovde je pozeljno koristiti Scanner objekat i Switch naredbu.
        Scanner scanner = new Scanner(System.in);
        System.out.println("Unesite velicinu");
        int velicina = scanner.nextInt();
        switch (velicina) {
            case 24:
                System.out.println("s vel");
                break;
            case 30:
                System.out.println("m vel");
                break;
            case 36:
                System.out.println("x vel");
                break;
            case 42:
                System.out.println("xl vel");
                break;
            default:
                System.out.println("pogresan unos");
        }
    }
}


