/*import java.util.Scanner;

public class Nizovi2 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int[] mojNiz = new int[3];
        for (int i = 0; i < 3; i++) {
            System.out.print("Unesite ime: ");
             mojNiz[] =new int[3];
        }
               for (int i = 0; i < mojNiz.length-1; i++)
        {
           String ime = mojNiz[i];
           if  (ime.startsWith("M")) {
                System.out.println(ime);) }

                            }
else{
                System.out.println("Nijedno ime ne pocinje sa m");

}}}}*/